# SIMPLIFIED FOR DEVPOST SUBMISSION

## What We're Keeping (SIMPLE & WORKING):

### 1. ✅ ElevenLabs Voice Coaching
- 13 exercise cards
- Click to activate Samantha
- She coaches through exercises
- Counts reps/holds with proper pacing
- **No complex client tools needed!**

### 2. ✅ Gemini Resource Finder  
- User types health question
- Gemini recommends trusted sources
- Simple, clear integration

### 3. ✅ Visual Timer/Counter
- On-page timer buttons (10/30/60 sec)
- Rep counter with audio beeps
- No AI needed - just helpful tools

---

## What We're REMOVING (Too Complex):

### ❌ Personalized Exercise Plans
- **Problem**: "Failed to fetch" errors
- **Why Remove**: Only 14 exercises, users naturally skip what they can't do
- **Decision**: Not needed!

### ❌ Progress Tracking System
- **Problem**: Requires Firebase Auth + Firestore setup
- **Why Remove**: Too complex for demo, many moving parts
- **Decision**: Save for v2

### ❌ ElevenLabs Client Tools
- **Problem**: Haven't configured in dashboard yet
- **Why Remove**: Not needed for basic voice coaching
- **Decision**: Samantha just reads scripts, no API calls

---

## SIMPLE ARCHITECTURE (What We'll Demo):

```
User Browser
    ↓
[Exercise Cards] → Click → Opens ElevenLabs widget
    ↓
Samantha speaks → Counts exercises → User completes workout
    
Separate feature:
[Resource Finder Form] → Gemini API → Returns recommendations
```

**No auth, no database, no complex integration - just two AI tools doing their jobs!**

---

## WHAT TO UPDATE:

### 1. Update Samantha's System Prompt (ElevenLabs Dashboard)
**NEW SIMPLIFIED VERSION:**

```
You are Samantha, a warm and encouraging senior fitness coach.

YOUR ROLE:
- Guide users through gentle chair exercises
- Count reps and holds slowly (2-3 seconds between numbers)
- Give safety reminders
- Encourage users warmly

COUNTING PACE (CRITICAL):
- Count SLOWLY: "One... (pause 2 sec)... Two... (pause 2 sec)... Three..."
- For holds: "Twenty... breathe... Nineteen... nice... Eighteen..."
- NEVER rush - seniors need time to move safely

EXAMPLE: "Five... breathe deeply... Four... you're doing great... Three... almost there... Two... one more... One... and release"

SAFETY REMINDERS:
- Stop immediately if you feel any pain
- Move slowly and gently
- Listen to your body

AVAILABLE EXERCISES (say these by name):
1. Hamstring Stretch - hold 20 seconds each leg
2. Figure 4 Stretch - hold 20 seconds each leg  
3. Spinal Twist - hold 20 seconds each side
4. Side Bends - hold 20 seconds each side
5. Neck Stretches - hold 20 seconds each direction
6. Warrior I - hold 20 seconds each side
7. Sit to Stands - 10 reps, rest, 10 more
8. Ankle Pumps - 10 circles each direction
9. Shoulder Circles - 10 forward, 10 back
10. Cat/Camel - 10 gentle movements
11. Arm Raises - 10 reps, rest, 10 more
12. Calf Raises - 10 reps, rest, 10 more
13. Shoulder Rolls - 10 forward, 10 back

KEEP IT SIMPLE:
- Just coach the exercise
- Count clearly
- Give encouragement
- That's it!

Remember: Your voice is their guide. Count clearly, pace slowly, and keep them encouraged!
```

### 2. Remove Complex Code (I'll do this)

### 3. Test Simple Flow:
1. User opens website
2. Clicks exercise card
3. ElevenLabs widget appears
4. User asks: "How do I do neck stretches?"
5. Samantha explains and counts
6. Done!

---

## DEVPOST NARRATIVE:

**"How We Use Both APIs"**

**ElevenLabs (Voice Interface):**
- Natural conversational AI for exercise coaching
- Counts reps and holds with proper senior-friendly pacing
- Provides safety reminders and encouragement
- Makes fitness accessible through voice

**Gemini (Intelligence Layer):**
- Analyzes health questions to recommend trusted resources
- Helps users find reliable information (Mayo Clinic, NIH, AARP)
- Ensures seniors get evidence-based guidance

**Why This Partnership Works:**
- ElevenLabs = Human touch (voice, personality, counting)
- Gemini = Smart research (finding credible sources)
- Together = Accessible fitness + trustworthy information

---

## JUDGES WILL SEE:

1. **Voice Coaching Demo:**
   - Click exercise → Samantha counts slowly
   - Shows ElevenLabs conversational AI

2. **Resource Finder Demo:**
   - Type "managing arthritis" → Gemini finds 5-7 trusted sources
   - Shows Gemini analysis capabilities

3. **Senior-Friendly Design:**
   - Large text, high contrast
   - Simple buttons
   - Clear voice guidance

**This is enough to win!** ✅

---

## TIME TO COMPLETE: 30 minutes

1. Update Samantha's system prompt in ElevenLabs (10 min)
2. Deploy simplified code (10 min)
3. Test both features (10 min)
4. Screenshot + video for DevPost

**No Firebase setup needed!**
**No client tools to configure!**
**Just clean, working features!**
