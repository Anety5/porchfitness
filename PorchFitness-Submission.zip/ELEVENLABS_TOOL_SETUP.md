# ElevenLabs Client Tools Configuration
**Copy these EXACT values into your ElevenLabs dashboard**

---

## TOOL 1: getRecentHistory

### Configuration Tab:
- **Name:** `getRecentHistory`
- **Description:** `Retrieve user's recent workout history to personalize greeting and track progress`
- **Wait for response:** ✅ CHECK THIS BOX
- **Disable interruptions:** ✅ CHECK THIS BOX

### Parameters:
**NONE** - This tool takes no parameters

### What it does:
When Samantha greets a user, she calls this tool to fetch their last 3 workouts from Firebase. Gemini then analyzes the data and creates a personalized greeting like:
> "Welcome back! Last time you did Neck Stretches - 3 reps, 60 seconds, pain level 2. Ready to continue your progress?"

---

## TOOL 2: logWorkout

### Configuration Tab:
- **Name:** `logWorkout`
- **Description:** `Log completed workout with exercise name, reps, duration, and pain level`
- **Wait for response:** ✅ CHECK THIS BOX
- **Disable interruptions:** ✅ CHECK THIS BOX

### Parameters: (Add 5 parameters in this exact order)

#### Parameter 1:
- **Name:** `exerciseName`
- **Type:** `string`
- **Required:** ✅ YES
- **Description:** `Name of the exercise completed (e.g., "Neck Stretches", "Seated Marching")`

#### Parameter 2:
- **Name:** `painLevel`
- **Type:** `number`
- **Required:** ✅ YES
- **Description:** `Pain level from 1-10 reported by user after exercise`

#### Parameter 3:
- **Name:** `notes`
- **Type:** `string`
- **Required:** ❌ NO (Optional)
- **Description:** `Optional notes about how the exercise felt or any concerns`

#### Parameter 4:
- **Name:** `repsCompleted`
- **Type:** `number`
- **Required:** ✅ YES
- **Description:** `Number of repetitions completed (for stretches: 3 reps, for strength: 20 reps total)`

#### Parameter 5:
- **Name:** `durationSeconds`
- **Type:** `number`
- **Required:** ✅ YES
- **Description:** `Total duration of exercise in seconds (for stretches: 60 seconds, for strength: varies)`

### What it does:
After Samantha guides a user through an exercise, she asks "How did that feel? Rate your pain 1-10." Then she logs the workout to Firebase with all the details.

---

## HOW SAMANTHA USES THESE TOOLS

### First Visit (New User):
1. User clicks "Sign In with Google"
2. User chooses an exercise
3. Samantha calls `getRecentHistory` → Returns empty (no history)
4. Samantha says: "Welcome! This is your first workout. Let's do neck stretches..."
5. Samantha counts: "Twenty... Nineteen... Eighteen..." (slow pace)
6. Samantha asks: "How did that feel? Rate pain 1-10?"
7. User says: "About a 2"
8. Samantha calls `logWorkout`:
   ```json
   {
     "exerciseName": "Neck Stretches",
     "painLevel": 2,
     "notes": "",
     "repsCompleted": 3,
     "durationSeconds": 60
   }
   ```
9. Samantha confirms: "I've logged 3 reps for 60 seconds with pain level 2. Great job!"

### Second Visit (Returning User):
1. User opens website (auto-signed in)
2. User chooses any exercise
3. Samantha calls `getRecentHistory` → Returns last 3 workouts
4. Gemini analyzes the data and creates greeting
5. Samantha says: "Welcome back! Last time you did Neck Stretches - 3 reps, 60 seconds, pain level 2. Your pain has improved from 3 to 2 since last week!"
6. Exercise continues normally...

---

## TESTING TIPS

### Test Tool 1 (getRecentHistory):
- Open your ElevenLabs agent
- Say: "Hello Samantha"
- Watch the conversation logs - you should see `getRecentHistory` called
- Response will be empty first time, then show data after you've logged workouts

### Test Tool 2 (logWorkout):
- After exercising, when Samantha asks about pain level
- Respond with a number: "About a 5"
- Watch logs - you should see `logWorkout` called with all 5 parameters
- Check Firebase Firestore to see if data was saved

---

## TROUBLESHOOTING

### If tools don't appear in Samantha's responses:
1. Make sure "Wait for response" is checked
2. Verify tool names match exactly: `getRecentHistory` and `logWorkout`
3. Check that your system prompt mentions these tools
4. Ensure Firebase functions are deployed and working

### If data isn't saving:
1. Check Firestore is enabled in Firebase Console
2. Verify user is signed in (check Auth in Firebase Console)
3. Look at Firebase function logs: `firebase functions:log`
4. Check browser console for errors

---

## SENIOR USER EXPERIENCE

**What seniors see:**
1. Big blue button: "Sign In with Google" 👆
2. Choose their Google account (one click)
3. Back to app - ready to exercise!
4. Click exercise card → Samantha starts talking
5. **That's it!** No setup, no configuration

**What they DON'T see:**
- Tool configurations
- Database operations
- API calls
- Technical details

**It's completely transparent and simple for them!** 🎉

---

## NEXT STEPS

1. ✅ Configure both tools in ElevenLabs (use values above)
2. ⏭️ Enable Firestore in Firebase Console
3. ⏭️ Enable Google Auth in Firebase Console
4. ⏭️ Test with a real workout!
