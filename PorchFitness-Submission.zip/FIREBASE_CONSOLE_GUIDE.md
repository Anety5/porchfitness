# Firebase Console - What To Add
**Quick Reference**

## ✅ What You Have (Already Working):
- ✅ Firebase Project: porchfitness-98628
- ✅ Hosting: Live at https://porchfitness-98628.web.app
- ✅ 3 Cloud Functions deployed
- ✅ Gemini API key configured

---

## ❌ What's Missing (Need to Enable):

### 1. Firestore Database
**Where:** Build → Firestore Database (left sidebar)  
**What to click:**
1. "Create database" button
2. Choose "Start in production mode"
3. Select location: **us-central1** (same as functions)
4. Click "Enable"
5. Wait 1-2 minutes

**After enabled, run in terminal:**
```powershell
firebase deploy --only firestore:rules
```

This deploys security rules so users can only see their own data.

---

### 2. Google Authentication
**Where:** Build → Authentication → Sign-in method tab  
**What to click:**
1. "Get started" (if first time)
2. Click "Google" provider row
3. Toggle switch to **"Enable"**
4. Add your email as support email
5. Click "Save"

**That's it!** Google sign-in is now active.

---

## 🎨 Button Design Update
✅ **DONE!** I've added a professional Gmail icon button to the header.

**What seniors will see:**
- Before sign-in: Clean button with colorful Google logo + "Sign In"
- After sign-in: Their name + "Sign Out" button
- Looks trustworthy (same Google logo they see on Gmail, YouTube, etc.)

---

## 📱 Senior User Experience

### What they do:
1. Open website
2. See Gmail logo button in top-right
3. Click "Sign In"
4. Choose their Google account (same as Gmail)
5. Back to app - ready to exercise!

### What they DON'T need to do:
- ❌ Create new account
- ❌ Remember password
- ❌ Fill out forms
- ❌ Configure anything

**It's exactly like signing into YouTube or Gmail - familiar and trusted!**

---

## ⏱️ Time Required
- Enable Firestore: **2 minutes**
- Enable Google Auth: **2 minutes**
- Deploy firestore rules: **1 minute**
- **Total: 5 minutes**

---

## 🧪 How to Test After Enabling

1. **Refresh website:** https://porchfitness-98628.web.app
2. **Look for button:** Top-right corner - Gmail icon with "Sign In"
3. **Click button:** Google account chooser popup appears
4. **Sign in:** Choose your account
5. **Success:** Your name appears + "Sign Out" button shows

**Try an exercise with Samantha to test full flow!**

---

## 🚀 Next Steps (In Order)

1. ✅ Read this guide
2. 📂 Open Firebase Console (already open in your screenshot)
3. 🗄️ Click "Firestore Database" in left sidebar → Create database
4. 🔐 Click "Authentication" in left sidebar → Enable Google
5. 💻 Run: `firebase deploy --only firestore:rules`
6. 🎯 Test the sign-in button on your website
7. 🎉 Done!
