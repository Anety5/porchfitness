# Quick Start - Complete in 35 Minutes

## For Seniors: Super Easy! ✅
**They just click "Sign In with Google" and start exercising. That's it!**

---

## For You (Setup - Do Once):

### 1️⃣ ElevenLabs Tools (10 min)
Go to: https://elevenlabs.io/app/conversational-ai

**Tool 1:** getRecentHistory
- Name: `getRecentHistory`
- Description: `Retrieve user's recent workout history to personalize greeting and track progress`
- Parameters: **NONE**
- ☑ Wait for response
- ☑ Disable interruptions

**Tool 2:** logWorkout  
- Name: `logWorkout`
- Description: `Log completed workout with exercise name, reps, duration, and pain level`
- Parameters: **5 total**
  1. `exerciseName` (string, required)
  2. `painLevel` (number, required)
  3. `notes` (string, optional)
  4. `repsCompleted` (number, required)
  5. `durationSeconds` (number, required)
- ☑ Wait for response
- ☑ Disable interruptions

### 2️⃣ Enable Firestore (5 min)
Click this link: https://console.firebase.google.com/project/porchfitness-98628/firestore

1. Click "Create Database"
2. Choose "Start in production mode"
3. Select "us-central1"
4. Click "Enable"
5. Run in terminal: `firebase deploy --only firestore:rules`

### 3️⃣ Enable Google Auth (5 min)
Click this link: https://console.firebase.google.com/project/porchfitness-98628/authentication/providers

1. Click "Get Started"
2. Click "Google"
3. Toggle "Enable"
4. Add your email
5. Click "Save"

### 4️⃣ Update System Prompt (5 min)
Go to ElevenLabs → Your Agent → System Prompt

Copy entire content from `SAMANTHA_SYSTEM_PROMPT.md` lines 6-137 and paste it.

### 5️⃣ Test (10 min)
1. Visit https://porchfitness-98628.web.app
2. Click "Sign In with Google"
3. Choose exercise
4. Talk to Samantha
5. Complete workout
6. Check Firestore for saved data

---

## How Seniors Use It:

```
1. Open website
2. Click "Sign In with Google" 👈 
3. Pick their Google account
4. Done! Start exercising
```

**No passwords to remember, no forms to fill, no configuration!**

---

## Need More Details?
- See `SETUP_NOW.md` for complete instructions
- See `ELEVENLABS_TOOL_SETUP.md` for tool parameters
- See `SAMANTHA_SYSTEM_PROMPT.md` for the prompt text
