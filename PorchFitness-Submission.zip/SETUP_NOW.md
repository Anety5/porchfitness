# Firebase Setup Checklist - DO THIS NOW
**5-10 minutes total**

---

## ✅ STEP 1: Configure ElevenLabs Tools (10 minutes)

Go to: https://elevenlabs.io/app/conversational-ai

1. Find your Samantha agent
2. Click "Client Tools" tab
3. Click "Add client tool" button

### Add Tool 1: getRecentHistory
```
Name: getRecentHistory
Description: Retrieve user's recent workout history to personalize greeting and track progress
☑ Wait for response
☑ Disable interruptions
Parameters: NONE
```
Click "Add tool"

### Add Tool 2: logWorkout
```
Name: logWorkout
Description: Log completed workout with exercise name, reps, duration, and pain level
☑ Wait for response
☑ Disable interruptions

Parameters (add 5):
1. exerciseName (string, REQUIRED) - Name of the exercise completed
2. painLevel (number, REQUIRED) - Pain level from 1-10 reported by user
3. notes (string, optional) - Optional notes about the exercise
4. repsCompleted (number, REQUIRED) - Number of repetitions completed
5. durationSeconds (number, REQUIRED) - Total duration in seconds
```
Click "Add tool"

**See ELEVENLABS_TOOL_SETUP.md for detailed instructions**

---

## ✅ STEP 2: Enable Firestore Database (5 minutes)

**I've opened the link for you in Simple Browser!**

Or go to: https://console.firebase.google.com/project/porchfitness-98628/firestore

### What to do:
1. Click **"Create Database"** button
2. Choose **"Start in production mode"** (we have security rules ready)
3. Select location: **us-central1** (must match your functions region)
4. Click **"Enable"**
5. Wait 1-2 minutes for database creation

### After database is created:
Open terminal and run:
```powershell
firebase deploy --only firestore:rules
```

This deploys the security rules so users can only access their own data.

---

## ✅ STEP 3: Enable Google Authentication (5 minutes)

Go to: https://console.firebase.google.com/project/porchfitness-98628/authentication/providers

### What to do:
1. Click **"Get Started"** (if first time)
2. Click **"Google"** provider from the list
3. Toggle the switch to **"Enable"**
4. Add support email: **your email address**
5. Click **"Save"**

**That's it!** Google Sign-In is now active.

---

## ✅ STEP 4: Update Samantha's System Prompt (5 minutes)

Go to: https://elevenlabs.io/app/conversational-ai

1. Find your Samantha agent
2. Click "System Prompt" tab
3. **Replace entire prompt** with the content from `SAMANTHA_SYSTEM_PROMPT.md`
4. Click "Save"

**Important:** The prompt needs to tell Samantha when and how to use the tools!

---

## ✅ STEP 5: Test Everything! (10 minutes)

### Test 1: Can you sign in?
1. Open https://porchfitness-98628.web.app
2. Click "Sign In with Google" button (top right)
3. Choose your Google account
4. Verify you see your name displayed

### Test 2: Does Samantha remember you?
1. Click any exercise card (e.g., "Neck Stretches")
2. Say "Hello Samantha"
3. Listen - she should say something like:
   - First time: "Welcome! This is your first workout."
   - OR if you have history: "Welcome back! Last time you did..."

### Test 3: Does workout logging work?
1. Do an exercise with Samantha
2. She counts: "Twenty... Nineteen... Eighteen..."
3. She asks: "How did that feel? Rate pain 1-10?"
4. Answer: "About a 2"
5. She should confirm: "I've logged 3 reps for 60 seconds..."

### Test 4: Check Firebase Console
1. Go to Firestore Console: https://console.firebase.google.com/project/porchfitness-98628/firestore/data
2. Look for: `users/{yourUserId}/sessions/{sessionId}`
3. You should see your workout data saved!

---

## 🎉 SUCCESS CRITERIA

You'll know it's working when:
- ✅ Sign in button works (Google OAuth popup appears)
- ✅ Your name appears after signing in
- ✅ Samantha greets you appropriately (first time vs returning)
- ✅ After exercise, data appears in Firestore
- ✅ On second visit, Samantha references your previous workout

---

## 🚨 TROUBLESHOOTING

### Sign-in button doesn't work:
- Check Google Auth is enabled in Firebase Console
- Check browser console for errors
- Try incognito mode

### Samantha doesn't remember me:
- Check ElevenLabs tools are configured correctly
- Verify `getRecentHistory` function is deployed
- Check function logs: `firebase functions:log`

### Workout data not saving:
- Verify Firestore is enabled
- Check user is signed in
- Look at browser console for errors
- Check function logs for `logWorkout`

### Tools not being called:
- Verify system prompt mentions the tools
- Check "Wait for response" is enabled
- Make sure tool names match exactly

---

## 📞 NEED HELP?

Run these diagnostic commands:

```powershell
# Check functions are deployed
firebase functions:list

# Check recent errors
firebase functions:log --limit 20

# Test Firestore access
firebase firestore:databases:list
```

---

## ⏰ TIME ESTIMATE

- ElevenLabs tools: 10 minutes
- Enable Firestore: 5 minutes
- Enable Google Auth: 5 minutes
- Update system prompt: 5 minutes
- Testing: 10 minutes

**TOTAL: 35 minutes**

---

## 🎯 WHAT SENIORS EXPERIENCE

**All they do:**
1. Click "Sign In with Google" 👈 ONE CLICK
2. Choose their account from list
3. Back to app automatically
4. Click exercise → Talk to Samantha

**That's it!** They don't see databases, tools, APIs, or any technical stuff.

**It's as simple as signing into Gmail!** 💙

---

Ready? Start with Step 1 (ElevenLabs tools) then work through Steps 2-5!
