# Firebase Console Setup Steps

## ✅ COMPLETED
- Cloud Functions deployed (3 functions)
- Hosting deployed
- Code ready

## 🔧 MANUAL STEPS NEEDED (Do these in Firebase Console)

### 1. Enable Firestore Database
1. Go to https://console.firebase.google.com/project/porchfitness-98628/firestore
2. Click "Create database"
3. Choose **"Start in production mode"** (we have security rules ready)
4. Select location: **us-central1** (same as functions)
5. Click "Enable"

### 2. Deploy Firestore Security Rules
After Firestore is created:
```bash
firebase deploy --only firestore:rules
```

### 3. Enable Google Sign-In
1. Go to https://console.firebase.google.com/project/porchfitness-98628/authentication/providers
2. Click "Get started" (if first time)
3. Click "Google" in the sign-in providers list
4. Toggle **"Enable"**
5. Set support email: your email
6. Click "Save"

### 4. Configure ElevenLabs Client Tools
Go to ElevenLabs Dashboard and add these TWO NEW tools:

**Tool 1: getRecentHistory**
- Name: `getRecentHistory`
- Description: "Retrieve user's recent workout history to personalize greeting"
- Parameters: None

**Tool 2: logWorkout**
- Name: `logWorkout`
- Description: "Log a completed workout session with reps, duration, and pain level"
- Parameters:
  * `exerciseName` (string, required): Name of the exercise completed
  * `painLevel` (number, required): Pain level from 1-10 where 1 is no pain
  * `notes` (string, optional): User's comments about how it felt
  * `repsCompleted` (number, required): Number of reps completed (e.g., 10 for strength, 3 for stretches)
  * `durationSeconds` (number, required): Total duration in seconds (e.g., 60 for 1-minute stretch)

### 5. Update Samantha's System Prompt
Copy the entire content from `SAMANTHA_SYSTEM_PROMPT.md` and paste into ElevenLabs agent settings.

---

## Testing Checklist

Once setup is complete:

1. [ ] Visit https://porchfitness-98628.web.app
2. [ ] Click "Sign In with Google" button in header
3. [ ] Sign in with your Google account
4. [ ] See your profile photo and name in header
5. [ ] Click an exercise card
6. [ ] Click ElevenLabs widget to start chat
7. [ ] Samantha should greet you (first time: "This is your first workout!")
8. [ ] Complete an exercise and answer her pain question
9. [ ] Refresh page and start another exercise
10. [ ] Samantha should remember your last workout!

---

## What's New - User Flow

**First Visit:**
1. User clicks "Sign In with Google"
2. Chooses neck stretches
3. Samantha: "Welcome! This is your first workout. Let's do neck stretches..."
4. After exercise: "How did that feel? Any pain from 1 to 10?"
5. User: "About a 2"
6. Samantha: "Great! I've logged this session so I can remember it next time."

**Second Visit (Days Later):**
1. User already signed in (persists)
2. Chooses any exercise
3. Samantha: "Welcome back! Last time you did neck stretches and they felt good with minimal discomfort. Ready to continue building on that progress?"
4. User workout with memory context
5. Progress tracked over time

---

## Architecture

```
User Browser
    ↓
Firebase Auth ← Google Sign-In
    ↓
Firestore DB ← Workout Sessions
    ↑
    ElevenLabs Widget ← Samantha's Voice
    ↑
    Client Tools:
    - getRecentHistory (calls Cloud Function)
    - logWorkout (saves to Firestore)
    ↑
    Gemini API ← Analyzes patterns, generates insights
```

---

## Deployed URLs

- **Website:** https://porchfitness-98628.web.app
- **Function: generatePersonalizedPlan:** https://generatepersonalizedplan-2ixqissjkq-uc.a.run.app
- **Function: findResources:** https://findresources-2ixqissjkq-uc.a.run.app
- **Function: getRecentHistory:** https://us-central1-porchfitness-98628.cloudfunctions.net/getRecentHistory

---

## Database Structure

```
users/
  {userId}/
    sessions/
      {sessionId}: {
        date: Timestamp,
        exerciseName: "Neck Stretches",
        painLevel: 2,
        notes: "felt pretty good",
        repsCompleted: 3,
        durationSeconds: 60,
        userId: "abc123"
      }
```

This allows querying user's workout history and showing progress over weeks!
