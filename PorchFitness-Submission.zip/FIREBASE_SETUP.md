# Firebase Setup Guide

## Prerequisites
- Firebase CLI installed: `npm install -g firebase-tools`
- Firebase project created at [console.firebase.google.com](https://console.firebase.google.com)
- Node.js 18+ installed

---

## 1. Gmail App Password Setup

### Step 1: Enable 2-Factor Authentication
1. Go to [myaccount.google.com](https://myaccount.google.com)
2. Click **Security** in left sidebar
3. Under "Signing in to Google", enable **2-Step Verification**
4. Follow prompts to set up (phone number/authenticator app)

### Step 2: Generate App Password
1. Still in **Security** section
2. Search for "App passwords" or go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Click **Select app** → Choose **Mail**
4. Click **Select device** → Choose **Other (Custom name)**
5. Type: `PorchFitness Firebase`
6. Click **Generate**
7. **Copy the 16-character password** (e.g., `abcd efgh ijkl mnop`)
8. Save it temporarily - you'll need it in Step 3

---

## 2. Install Dependencies

```bash
cd functions
npm install
npm install nodemailer
cd ..
```

---

## 3. Set Firebase Secrets

### Login to Firebase
```bash
firebase login
```

### Set Gmail User (Your Email)
```bash
firebase functions:secrets:set GMAIL_USER
```
- When prompted, enter your full Gmail address: `youremail@gmail.com`
- Press Enter

### Set Gmail App Password
```bash
firebase functions:secrets:set GMAIL_APP_PASSWORD
```
- When prompted, enter the 16-character password from Step 1
- **Important**: Remove spaces (e.g., `abcdefghijklmnop`)
- Press Enter

### Verify Secrets (Optional)
```bash
firebase functions:secrets:access GMAIL_USER
firebase functions:secrets:access GMAIL_APP_PASSWORD
```

---

## 4. Deploy Cloud Functions

### Deploy All Functions
```bash
firebase deploy --only functions
```

### Deploy Single Function (if needed)
```bash
firebase deploy --only functions:sendWeeklySummaryEmail
```

---

## 5. Test Email Sending

### Option A: Test from Progress Dashboard
1. Open your deployed site
2. Sign in with Google
3. Click "📊 Email My Weekly Stats" button
4. Check your Gmail inbox

### Option B: Test from Firebase Console
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Select your project
3. Click **Functions** in left sidebar
4. Find `sendWeeklySummaryEmail`
5. Click **Logs** to see any errors

### Option C: Test Locally
```bash
cd functions
npm run serve
# In another terminal:
curl -X POST http://localhost:5001/YOUR-PROJECT-ID/us-central1/sendWeeklySummaryEmail \
  -H "Content-Type: application/json" \
  -d '{"data": {"userId": "YOUR_USER_ID"}}'
```

---

## 6. Troubleshooting

### "Invalid login" or "Application-specific password required"
- Make sure 2FA is enabled on your Google account
- Regenerate the App Password
- Ensure no spaces in the password when setting secret

### "Permission denied" on secrets
```bash
# Give functions access to secrets
firebase functions:secrets:set GMAIL_USER --force
firebase functions:secrets:set GMAIL_APP_PASSWORD --force
firebase deploy --only functions
```

### Email not sending
1. Check Firebase Functions logs:
   ```bash
   firebase functions:log
   ```
2. Check Firestore Rules allow reading `users/{userId}/sessions`
3. Verify user has workouts in Firestore

### CORS errors
- Make sure `cors` is installed: `cd functions && npm install cors`
- Redeploy functions

---

## 7. Environment Variables (Alternative to Secrets)

If secrets don't work, use environment variables:

### Set Environment Variables
```bash
firebase functions:config:set gmail.user="youremail@gmail.com"
firebase functions:config:set gmail.password="your-app-password"
```

### Update functions/index.js
Replace:
```javascript
const gmailUser = process.env.GMAIL_USER;
const gmailPassword = process.env.GMAIL_APP_PASSWORD;
```

With:
```javascript
const gmailUser = functions.config().gmail.user;
const gmailPassword = functions.config().gmail.password;
```

### Deploy
```bash
firebase deploy --only functions
```

---

## 8. Security Checklist

- [ ] Never commit secrets to Git
- [ ] Add to `.gitignore`:
  ```
  .env
  .env.local
  functions/.env
  functions/serviceAccountKey.json
  ```
- [ ] Use App Password (not actual Gmail password)
- [ ] Restrict Firebase Functions to authenticated users only
- [ ] Set Firestore security rules to prevent unauthorized access

---

## 9. Firestore Security Rules

Update `firestore.rules`:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only read/write their own data
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Deploy rules:
```bash
firebase deploy --only firestore:rules
```

---

## 10. Quick Reference

### Common Commands
```bash
# Login
firebase login

# Set secret
firebase functions:secrets:set SECRET_NAME

# Deploy functions
firebase deploy --only functions

# View logs
firebase functions:log

# Local testing
cd functions && npm run serve
```

### Project Structure
```
porchfitness-elevenlabs-challenge/
├── functions/
│   ├── index.js           # Cloud Functions code
│   ├── package.json       # Dependencies (nodemailer, etc.)
│   └── .env              # Local secrets (NOT in Git)
├── firestore.rules        # Database security
├── firebase.json          # Firebase config
└── .firebaserc           # Project aliases
```

---

## Need Help?

- Firebase Functions docs: [firebase.google.com/docs/functions](https://firebase.google.com/docs/functions)
- Nodemailer docs: [nodemailer.com](https://nodemailer.com)
- Gmail App Passwords: [support.google.com/mail/answer/185833](https://support.google.com/mail/answer/185833)

Contact: aloha@lavarocklabs.com
